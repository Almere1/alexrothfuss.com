import pandas as pd







def hashit(List, IPList):
    goto = List.split(" ")
    hashing = {}
    i = 0
    for ip in IPList.split(" "):
        hashing[ip] = goto[i]
        i+=1
    return hashing

def main():


    callList = "https://www.youtube.com/results?search_query=keyword https://www.yelp.com/search?find_desc=%3Ckeyword%3E&find_loc=Chicago%2C+IL https://www.amazon.com/s?k=keyword&ref=nb_sb_noss_2 https://www.walmart.com/search/?query=%3Ckeyword%3E https://cs.stanford.edu/search/node/keyword"

    ipCall = "216.58.192.142 151.101.52.116 205.251.242.103 161.170.230.170 171.64.64.64"


    WebListOne=("yelp.com youtube.com cnn.com nytimes.com kidshealth.org webmd.com cs.uchicago.edu cs.stanford.edu whitehouse.gov https://www.nsf.gov/ amazon.com walmart.com")
    WebListOneIP=("151.101.52.116 216.58.192.142 151.101.193.67 151.101.129.164 192.234.249.117 207.231.204.56 128.135.164.125 171.64.64.64 104.70.144.123 128.150.4.107 205.251.242.103 161.170.230.170")
    WebHashOne = hashit(WebListOne, WebListOneIP)
    WebHashThree = hashit(callList, ipCall)

    
    listemPing1 = []
    listemTrace1 = []
    listemTraceTotal1 = []
    read_one = open('seq1_akrothfuss.txt', 'r')


    readlines = read_one.readlines()
    date = time = "Not"





#-----------------------------------------------------------#
#                      SEQUENCE 1                           #
#-----------------------------------------------------------#
#
#
    flag = 0
    traceFlag = 0
    pingList = []
    service = "Not"
    for line in readlines:
        if "BEGIN" in line:
            date = line[line.find("April"):line.find("April")+13]
            time = line[line.find("April")+14:line.find("\n")]



        if (flag == 1):
            if "64 bytes" in line:
                pingList.append(line[line.find("time")+5:line.find("\n")])




        if "PING" in line:
            flag = 1
            pingList = []
            service = line.split(" ")[1]
        elif "ping statistics" in line:
            summa = 0
            flag = 0
            for span in pingList:
                summa+=float(span.split(" ")[0])

            if (len(pingList)>0):
                summa /= len(pingList)
            else:
                pingList = []
                summa = 0
            listemPing1.append([WebHashOne[service]+"("+service+")", date, time, pingList, (str(summa)+" ms") if (summa != 0) else ("No Response")])

        elif (flag == 0): 
            if "30  * * *" in line:
                listemTrace1.append([WebHashOne[service]+"("+service+")", date, time, 30, pingList.append("* * *"), "N/A", "N/A", "N/A", "N/A"])
                traceFlag = 0
                listemTraceTotal1.append([WebHashOne[service]+"("+service+")", date, time, "N/A"])

            if service in line:
                if not "packets" in line:
                    if service in line:
                        addTo=([WebHashOne[service]+"("+service+")", date, time, line.split("  ")[0], line[line.find("(")+1:line.find(")")]])
                        lenList = line.split(" ms")
    
                        summa = 0
                        for item in lenList:
                            if ("." in item):
                                addTo.append(item[item.rfind(" "):]+" ms")
                                summa+=float(item[item.rfind(" "):])
                            #elif (("*") in item)
    
                        summa/=(3-(8-len(addTo)))
                        while(len(addTo)<8):
                            addTo.append("N/A")
    
                        addTo.append(str(summa) + " ms")
                        listemTrace1.append(addTo);
                    traceFlag = 0
                    listemTraceTotal1.append([WebHashOne[service]+"("+service+")", date, time, int(line.split("  ")[0])])

                elif "packets" in line:
                    traceFlag = 1

            elif "(" in line and not "packets" in line:
                    addTo=([WebHashOne[service]+"("+service+")", date, time, int(line.split("  ")[0]), line[line.find("(")+1:line.find(")")]])
                    lenList = line.split(" ms")

                    summa = 0
                    for item in lenList:
                        if ("." in item):
                            addTo.append(item[item.rfind(" "):]+" ms")
                            summa+=float(item[item.rfind(" "):])
                        #elif (("*") in item)

                    summa/=(3-(8-len(addTo)))
                    while(len(addTo)<8):
                        addTo.append("N/A")

                    addTo.append(str(summa) + " ms")
                    listemTrace1.append(addTo);



    read_one.close()
#-----------------------------------------------------------#
#                      SEQUENCE 3                           #
#-----------------------------------------------------------#
#
# There is no traceroute, so I'll ignore that portion of the 
# assignment
#
    read_three = open('seq3_akrothfuss.txt', 'r')
    listemPing3 = []
    listemAPI3 = []

    flag = 0
    countUp = 0
    traceFlag = 0
    pingList = []
    service = "Not"
    for line in readlines:
        if "BEGIN" in line:
            date = line[line.find("April"):line.find("April")+13]
            time = line[line.find("April")+14:line.find("\n")]



        if (flag == 1):
            if "64 bytes" in line:
                pingList.append(line[line.find("time")+5:line.find("\n")])




        if "PING" in line:
            flag = 1
            pingList = []
            service = line.split(" ")[1]
        elif "ping statistics" in line:
            summa = 0
            flag = 0
            for span in pingList:
                summa+=float(span.split(" ")[0])

            if (len(pingList)>0):
                summa /= len(pingList)
            else:
                pingList = []
                summa = 0
            listemPing3.append([WebHashOne[service]+"("+service+")", date, time, pingList, (str(summa)+" ms") if (summa != 0) else ("No Response")])

        elif (flag == 0): 
            if "real\t" in line:
                service = ipCall.split(" ")[countUp] 
                
                print(line)
                listemAPI3.append([WebHashOne[service]+"("+service+")", "GET " + WebHashThree[service], date, time, line.split("\n")[0][5:]])
                
                countUp += 1
                if(countUp == 5):
                    countUp = 0


    read_three.close()

#-----------------------------------------------------------#
#                      DATATYPES                            #
#-----------------------------------------------------------#
#
# I elected to create a unique file for different datatypes 
# as well, since otherwise it'll give pandas issues, and
# it'll be difficult to read
# 

    for service in WebListOneIP.split(" "):
        write_one = open('seq1_'+WebHashOne[service]+"_ping.csv", 'w')
        write_two = open('seq1_'+WebHashOne[service]+"_trace.csv", 'w')
        write_three = open('seq1_'+WebHashOne[service]+"_traceTotal.csv", 'w')

        temp = []
        for item in listemPing1:
            if service in item[0]:
            temp.append(item)

        write_one = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Ping Delays", "Average Ping Delay"])
        write_one.to_csv('seq1_'+WebHashOne[service]+"_ping.csv", index=False, na_rep='Unknown')


        temp = []
        for item in listemTrace1:
            if service in item[0]:
            temp.append(item)

        write_two = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Index", "Hop IP", "Delay1", "Delay2", "Delay3", "Average Ping Delay"])
        write_two.to_csv('seq1_'+WebHashOne[service]+"_trace.csv", index=False, na_rep='Unknown')

        temp = []
        for item in listemTraceTotal1:
            if service in item[0]:
            temp.append(item)

        write_three = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Total Count"])
        write_three.to_csv('seq1_'+WebHashOne[service]+"_traceTotal.csv", index=False, na_rep='Unknown')

        write_three.close()
        write_two.close()
        write_one.close()


    for service in ipCall.split(" "):
        write_one = open('seq3_'+WebHashThree[service]+"_ping.csv", 'w')
        write_two = open('seq3_'+WebHashOne[service]+"_APICall.csv", 'w')

        temp = []
        for item in listemPing1:
            if service in item[0]:
            temp.append(item)

        write_one = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Ping Delays", "Average Ping Delay"])
        write_one.to_csv('seq3_'+WebHashOne[service]+"_ping.csv", index=False, na_rep='Unknown')

        temp = []
        for item in listemTraceTotal1:
            if service in item[0]:
            temp.append(item)

        write_two = pd.DataFrame(temp, columns=['Service', "Date", "Time", "End-to-End Delay"])
        write_two.to_csv('seq3_'+WebHashOne[service]+"_traceTotal.csv", index=False, na_rep='Unknown')

        write_two.close()
        write_one.close()

    for item in listemPing1:
        print(item)
    for item in listemTrace1:
        print(item)
    for item in listemPing3:
        print(item)
    for item in listemAPI3:
        print(item)


if __name__ == "__main__":
    main();
