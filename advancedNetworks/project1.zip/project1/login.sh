#!/usr/bin/env bash
#NOTE: Depricated password
sshpass -p "WhyWhyWhyWhy1" ssh -o StrictHostKeyChecking=no akrothfuss@linux.cs.uchicago.edu
