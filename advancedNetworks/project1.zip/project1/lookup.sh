#!/usr/bin/env bash

WebListTwo=("youtube.com walmart.com amazon.com kidshealth.org cnn.com")
WebListThree=("youtube.com yelp.com amazon.com walmart.com cs.stanford.edu")
WebListOne=("151.101.52.116 216.58.192.142 151.101.193.67 151.101.129.164 192.234.249.117 207.231.204.56 128.135.164.125 171.64.64.64 104.70.144.123 128.150.4.107 205.251.242.103 161.170.230.170")
#sequence 1

for item in $WebListOne; do
        time ping -w10 $item
done

##sequence 2
#
#for item in $WebListTwo; do
#        { host $item; } &>> dns2.txt
#done
#
##sequence 3
#
#for item in $WebListThree; do
#        { host $item; } &>> dns3.txt
#done
~                                                           
