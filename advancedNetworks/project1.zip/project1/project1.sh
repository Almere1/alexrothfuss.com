#!/usr/bin/env bash

WebListOne=("yelp.com youtube.com cnn.com nytimes.com kidshealth.org webmd.com cs.uchicago.edu cs.stanford.edu whitehouse.gov https://www.nsf.gov/ amazon.com walmart.com")
WebListTwo=("youtube.com walmart.com amazon.com kidshealth.org cnn.com")
WebListThree=("youtube.com yelp.com amazon.com walmart.com cs.stanford.edu")

echo "$(date '+%A %B %d %Y %r')" >> seq1_akrothfuss.txt
echo "$(date '+%A %B %d %Y %r')" >> seq2_akrothfuss.txt
echo "$(date '+%A %B %d %Y %r')" >> seq3_akrothfuss.txt

#sequence 1

for item in $WebListOne; do
	time ping -w10 $item >> seq1_akrothfuss.txt
	traceroute $item >> seq1_akrothfuss.txt
	traceroute $item >> seq1_akrothfuss.txt
	traceroute $item >> seq1_akrothfuss.txt
	echo "\n\n\n\n\n" >> seq1_akrothfuss.txt

done

#sequence 2

for item in $WebListTwo; do
	traceroute $item >> seq2_akrothfuss.txt
	pchar -c -R 4 -I 128 -p ipv4icmp item >> seq2_akrothfuss.txt
	time ping -w10 $item >> seq2_akrothfuss.txt
	pchar -c -R 4 -I 128 -p ipv4icmp item >> seq2_akrothfuss.txt
	traceroute $item >> seq2_akrothfuss.txt
	echo "\n\n\n\n\n" >> seq2_akrothfuss.txt
done

#sequence 3

for item in $WebListThree; do
	time GET https://www.cnn.com/search?q=%3Ckeyword%3E >> seq3_akrothfuss.txt
	time ping -w10 $item >> seq3_akrothfuss.txt
	time GET https://www.cnn.com/search?q=%3Ckeyword%3E >> seq3_akrothfuss.txt
	time ping -w10 $item >> seq3_akrothfuss.txt
	time GET https://www.cnn.com/search?q=%3Ckeyword%3E >> seq3_akrothfuss.txt
	time ping -w10 $item >> seq3_akrothfuss.txt
	echo "\n\n\n\n\n" >> seq3_akrothfuss.txt
done
