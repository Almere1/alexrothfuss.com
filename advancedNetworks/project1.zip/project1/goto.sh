#!/usr/bin/env bash

# Iterate the string variable using for loop
	WebList=("yelp.com youtube.com cnn.com nytimes.com kidshealth.org webmd.com cs.uchicago.edu cs.stanford.edu whitehouse.gov https://www.nsf.gov/ amazon.com walmart.com")

	for item in $WebList; do
		time ping -w10 $item >> seq1_akrothfuss.txt
		traceroute $item >> seq1_akrothfuss.txt
		traceroute $item >> seq1_akrothfuss.txt
		traceroute $item >> seq1_akrothfuss.txt
	done
