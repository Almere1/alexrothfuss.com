//HOLY SHIT this one was a pain. I want to re-implement with ambiguous data types, but... not
//today! 
//
//Novel implementations
/*
 * Option - Cozy enum
 * Box - holds data of ambiguous size on the heap. important because a link contains an option.
 * match - checks which enum option i got
 * impl - allows you to add functions to structs
 * & - reference
 * &mut - mutable reference
 * * - dereference
 *
 *
 *
 * Can you do implication with something like - [x y -> z] ?????
 */

fn main() {
    let mut erm = Link{
        data: 1,
        next: Some(Box::new(Link::new_with_data(10))),
    };

    let next: Link = match erm.next{
        Some(x) => *x,
        None => Link::new(),
    };

    let mut start = Link::new();
    start.push(8);
    start.push(5);
    start.push(1000005);
    start.print_list();

    println!("Hello, world! {}", erm.data);
    println!("AND! {}", next.data);

    erm.data = 20;
    println!("{}", erm.data);
}


struct Link{
    data: i32,
    next: Option<Box<Link>>,
}


impl Link{
    fn new() -> Link{
        Link {
            data: 1,
            next: None,
        }
    }

    fn new_with_data(data: i32) -> Link{
        Link {
            data,
            next: None, 
        }
    }

    fn push(&mut self, data: i32){ 
        match &mut self.next{
            Some(get) => get.push(data),
            None => self.next = Some(Box::new(Link::new_with_data(data))),
        };
    }

    fn delete(&mut self, index: u64){ 
        if index == 1 {
            let holder = self;
            match &self.next{
                Some(next) => {
                    match &next.next{
                        Some(newNext) => self.next = newNext,
                        None => println!("Deletion out of range!"),
                    };
                }
                None => println!("Deletion out of range!"),
            };
        }
        else if index == 0{
           println!("Can't delete first value");
        }
        else{
            match &self.next{
                Some(next) => next.delete(index-1),
                None => println!("Deletion out of range!"),
            };
        }
    }

    fn print_list(&self){
        match &self.next{
            Some(val) => {
                print!("{} -> ", self.data);
                val.print_list() 
            }
            None => println!("{}", self.data),
        };
    }
}
