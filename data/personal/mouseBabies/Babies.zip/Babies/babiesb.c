#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() { 
    long bucket_one, bucket_two=0, bucket_three = 0;
    bucket_one = 1;
    long gestation_one = 0, gestation_two = 0, gestation_three = 0;

    for(int i = 0; i<5000; i++){
        if(i && (i % 60) == 0){
        	gestation_three = bucket_one*3;
       	bucket_one += gestation_one;
        	gestation_one = 0;
        	
        }
        if(i-20 && ((i-20) % 60) == 0){
        	gestation_one = bucket_two * 3;
        	bucket_two += gestation_two;
        	gestation_two = 0;
        }
        if(i-40 && ((i-40) % 60) == 0){
        	gestation_two = bucket_three * 3;
        	bucket_three += gestation_three;
        	gestation_three = 0;
        }
    }
    
    printf("MAMA!\n");
    printf("%li \n",2*( bucket_one+bucket_two+bucket_three+gestation_one+gestation_two+gestation_three));
}
