#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Mice{
int mature; 
int gestation;
struct Mice *baby[63]; 
} Mouse; 

int newbabies(Mouse* female){
    int babynum = 0;
    while(female->baby[babynum]){
        babynum++;
    }
    for(int i = babynum; i<babynum+3; i++){
        female->baby[i] = malloc(sizeof(Mouse));
        female->baby[i]->mature = 40;
        female->baby[i]->gestation = 60;
    }
    female->gestation = 60;
}

long checkbabies(Mouse* female){
    if(female->mature) female->mature--;
    else if(female->gestation) female->gestation--;
    
    if(!female->gestation) newbabies(female);
    
    
    int babynum = 0;
    long babysum = 1;
    
    
    while(female->baby[babynum]){
        babysum += checkbabies(female->baby[babynum]);
        babynum++;
    }
    return babysum;
}

int freebabies(Mouse* female){

    int babynum = 0;    
    while(female->baby[babynum]){
        freebabies(female->baby[babynum]);
        babynum++;
    }
    free(female);
    return 0;
}

int main() {    


    Mouse *mother = malloc(sizeof(Mouse));
    mother->mature = 0;
    mother->gestation = 60;
    
    for(int i = 0; i < 125; i++){
    	checkbabies(mother);
    }
    long igg = checkbabies(mother);
    
    printf("mother?\n");
    printf("%li \n", igg);
    if(mother->baby[0]) printf("%i", mother->baby[0]->gestation);
    else printf("HEY HEY HEY");
    freebabies(mother);
    
    
}


