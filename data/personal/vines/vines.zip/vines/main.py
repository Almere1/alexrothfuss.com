import cairo
import numpy as np

def gradient(self):
        self.linear = cairo.LinearGradient(0, 0, 1, 1)
        self.linear.add_color_stop_rgb(0, 0, 0.3, 0.8)
        self.linear.add_color_stop_rgb(1, 0, 0.8, 0.3)

        self.radial = cairo.RadialGradient(0.5, 0.5, 0.25, 0.5, 0.5, 0.75)
        self.radial.add_color_stop_rgba(0, 0, 0, 0, 1)
        self.radial.add_color_stop_rgba(0.5, 0, 0, 0, 0)

        cairo.set_source(self.linear)
        cairo.mask(self.radial)

    denom = ((y4-y3)*(x2-x1)-(x4-x3)*(y2-y1))
    if denom == 0:
        return -1,-1
    u1 = ((x4-x3)*(y1-y3)-(y4-y3)*(x1-x3))/denom
    u2 = ((x2-x1)*(y1-y3)-(y2-y1)*(x1-x3))/denom     
    xRet = x1+u1*(x2-x1)
    yRet = y1+u1*(y2-y1)

#    if (xRet <= max([x3, x4])) and (xRet >= min([x3, x4])) and (yRet <= max([y3, y4])) and (yRet >= min([y3, y4])):
#        if (xRet <= max([x1, x2])) and (xRet >= min([x1, x2])) and (yRet <= max([y1, y2])) and (yRet >= min([y1, y2])):
    if (xRet < max([x3, x4])) and (xRet > min([x3, x4])) and (yRet < max([y3, y4])) and (yRet > min([y3, y4])):
        if (xRet <= max([x1, x2])) and (xRet >= min([x1, x2])) and (yRet <= max([y1, y2])) and (yRet >= min([y1, y2])):
#        if (xRet < max([x1, x2])) and (xRet > min([x1, x2])) and (yRet < max([y1, y2])) and (yRet > min([y1, y2])):
            return (xRet, yRet)
    return (-1, -1)

def nodeSplit(context, nodeX, nodeY, angle, length, variance, wallList):
    angles = [np.random.normal(.1*np.sqrt(variance),.05*np.sqrt(variance)), np.random.normal(-.1*np.sqrt(variance),.05*np.sqrt(variance))]
    tupleList = []
    flag = 0
    for i in range(2):
        curvetuple = []
        tempX = nodeX
        tempY = nodeY
        tempA = angle
        context.move_to(tempX, tempY)
        for ii in range(2):
            holdX = tempX
            holdY = tempY
            tempA = angles[i] + tempA
            tempY = tempY-np.cos(tempA*np.pi)*length
            tempX = tempX+np.sin(tempA*np.pi)*length

            for wall in wallList:
                coll = collision(wall[0],wall[1], wall[2], wall[3], holdX, holdY, tempX, tempY)
                while(coll[0] != -1):
                    tempA += .05 * (1-i*2)
                    tempY = holdY-np.cos(tempA*np.pi)*length
                    tempX = holdX+np.sin(tempA*np.pi)*length
                    coll = collision(wall[0],wall[1], wall[2], wall[3], holdX, holdY, tempX, tempY)

            curvetuple.append((tempX, tempY))

            if len(curvetuple) == 2:
                context.curve_to(curvetuple[0][0], curvetuple[0][1], curvetuple[0][0], curvetuple[0][1], curvetuple[1][0], curvetuple[1][1])
                context.stroke()
        tupleList.append((tempX, tempY, tempA))
    return tupleList



def addwall(context, x1, y1, x2,  y2, visible):
    if(visible):
        context.move_to(x1, y1)
        context.line_to(x2, y2)
        context.stroke()
    return (x1, y1, x2, y2)
    
def createVine(seed, context, wallList, generations, direction, livingNodes, branchLen): 
    def getY(n):
        return n[1]
    def getX(n):
        return n[0]

    nodelist = [seed]
    nodelistnext = []
    for i in range(generations):
        index = 0
        for tup in nodelist:
            nodelistnext+=nodeSplit(context, tup[0], tup[1], tup[2], branchLen, (len(nodelist)-index), wallList)
            index+=1

        if direction == "up":
            nodelistnext.sort(key=getY)
        elif direction == "down":
            nodelistnext.sort(key=getY, reverse=True)
        elif direction == "left":
            nodelistnext.sort(key=getX)
        elif direction == "right":
            nodelistnext.sort(key=getX, reverse=True)
        nodelist = nodelistnext if len(nodelistnext)<livingNodes else nodelistnext[0:livingNodes] 
        nodelistnext = []
    

def attempt():
    wallList = []
    with cairo.SVGSurface("example.svg", 400, 800) as surface:
        context = cairo.Context(surface)
        context.scale(200, 200)
        context.set_line_width(0.01)
        context.move_to(.5,3.5)
        context.arc(.5,3.5,.25*np.sqrt(2),-.250*np.pi, .01*np.pi) 
        seed = (1.5, 4, 0)
        wallList.append(addwall(context, 0,1,1.1,1, True))
        wallList.append(addwall(context, 0,.5,1.1,.5, False))
        wallList.append(addwall(context, 1,1,1,4, True))
        wallList.append(addwall(context, 1.5,1,1.5,4, False))
        #createVine((1, .999, 0), context, wallList, 40, "down", 4, .05)
        #createVine((1, .999, 0), context, wallList, 20, "left", 4, .05)
        createVine((1, 1, 0), context, wallList, 40, "down", 4, .05)
        createVine((1, 1, 0), context, wallList, 20, "left", 4, .05)

if __name__ == "__main__":
    attempt()
    np.random.normal(0,.1)







#def nodeSplitThree(context, nodeX, nodeY, angle, length, variance, wallList):
#    print(wallList)
#    angles = [np.random.normal(.1*np.sqrt(variance),.05*np.sqrt(variance)), np.random.normal(-.1*np.sqrt(variance),.05*np.sqrt(variance))]
#    tupleList = []
#    for i in range(2):
#        curvetuple = []
#        tempX = nodeX
#        tempY = nodeY
#        tempA = angle
#        context.move_to(tempX, tempY)
#        for ii in range(3):
#            tempA = angles[i] + tempA
#            tempY = tempY-np.cos(tempA*np.pi)*length
#            tempX = tempX+np.sin(tempA*np.pi)*length
#            tempX = tempX if tempX<2 else 2
#            tempX = tempX if tempX>0 else 0
#            curvetuple.append((tempX, tempY))
#            if len(curvetuple) == 3:
#                context.curve_to(curvetuple[0][0], curvetuple[0][1], curvetuple[1][0], curvetuple[1][1], curvetuple[2][0], curvetuple[2][1])
#                context.stroke()
#        tupleList.append((tempX, tempY, tempA))
#    return tupleList
#
#def filterTopN(tupleList, n):
#    retList = []
#    if len(tupleList)<=n:
#        return tupleList
#    else:
#        retList = tupleList[0:n] 
#        for i in range(n, len(tupleList)):
#            for check in range(len(retList)):
#                if retList[check][1] > tupleList[i][1]:
#                    retList[check] = tupleList[i]
#                    break
#        return retList
#def attempt():
#    nodelist = []
#    nodelistnext = []
#    wallList = []
#    with cairo.SVGSurface("example.svg", 400, 800) as surface:
#        context = cairo.Context(surface)
#        context.scale(200, 200)
#        context.set_line_width(0.01)
#        nodelist.append((1, .98, 0))
#        wallList.append(addwall(context, 0,1,1.1,1))
#        wallList.append(addwall(context, 1,1,1,4))
#        for i in range(50):
#            index = 0
#            for tup in nodelist:
#                nodelistnext+=nodeSplit(context, tup[0], tup[1], tup[2], .05, (len(nodelist)-index), wallList)
#                index+=1
#            nodelistnext.sort(key=getY)
#            nodelist = nodelistnext if len(nodelistnext)<4 else nodelistnext[len(nodelistnext)-4:len(nodelistnext)] 
#            nodelistnext = []
#def example():
#    with cairo.SVGSurface("example.svg", 200, 200) as surface:
#        context = cairo.Context(surface)
#        x, y, x1, y1 = 0.1, 0.5, 0.4, 0.9
#        x2, y2, x3, y3 = 0.6, 0.1, 0.9, 0.5
#        context.scale(200, 200)
#        context.set_line_width(0.04)
#        context.move_to(x, y)
#        context.curve_to(x1, y1, x2, y2, x3, y3)
#        context.stroke()
#        context.set_source_rgba(1, 0.2, 0.2, 0.6)
#        context.set_line_width(0.02)
#        context.move_to(x, y)
#        context.line_to(x1, y1)
#        context.move_to(x2, y2)
#        context.line_to(x3, y3)
#        context.stroke()
#
#        context.move_to(0,0)
#        context.line_to(1,1)
#        context.line_to(0,1)
#        context.stroke()
#        context.move_to(0,0)
#        context.curve_to(1,1,1,1,0,1)
#        context.stroke()
