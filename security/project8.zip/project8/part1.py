import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')

################################################################################
# Problem 1
################################################################################

def deidentify(df):
    retval = df.drop(columns=["Name", "SSN"])
    return retval

def pii(df):
#    col = df.columns 
    retval = df[["Name","DOB","SSN", "Zip"]]
#    for item in col:
#        print(item)
#        if item not in :
            
    return retval 

def link_attack(deidentified_df, pii_df):
    retval = pd.merge(pii_df,deidentified_df, on=["DOB", "Zip"])
    retval = retval.drop_duplicates(subset=["DOB", "Zip"], keep=False)
    return retval

################################################################################
# Problem 1.2
################################################################################

def is_k_anon(df, cols, k):
    for item in cols:
        if (df[[item]].nunique().values[0]) > k:
            return False
    return True

################################################################################
# Problem 1.3
################################################################################

def num_bachelors(df):
    retval = df[df["Education"]=="Bachelors"]
    return len(retval.index)

def laplace_mech(query, sensitivity, epsilon):
    noise = np.random.laplace(0.0, scale = sensitivity/epsilon)
    return query+noise

def make_plot_3():
    query = 200.0
    sensitivity = 1
    epsilons = [.5, 1, 10]
    for epsilon in epsilons:
        samples = []
        i = 0
        while i < 10000:
            samples.append(laplace_mech(query, sensitivity, epsilon))
            i+=1
        plt.hist(samples, bins = 50)

#    plt.savefig("/home/alex/part2/assignment_8/problem3.png")
    plt.show()
    

################################################################################
# Problem 1.4
################################################################################

def make_plot_4():
    queries = [200.0,201.0]
    sensitivity = 1
    epsilon = .05 
    for query in queries:
        samples = []
        i = 0
        while i < 10000:
            samples.append(laplace_mech(query, sensitivity, epsilon))
            i+=1
        plt.hist(samples, bins = 50)

#    plt.savefig("/home/alex/part2/assignment_8/problem4.png")
    plt.show()
    

################################################################################
# Problem 1.5
################################################################################

def make_plot_5():
    query = 200.0
    sensitivity = 1
    epsilons = [.5, 1, 10]
    for epsilon in epsilons:
        samples = []
        i = 0
        while i < 10000:
            samples.append(abs(200-laplace_mech(query, sensitivity, epsilon)))
            i+=1
        plt.hist(samples, bins = 50)

#    plt.savefig("/home/alex/part2/assignment_8/problem5.png")
    plt.show()

# driver/test code below here

