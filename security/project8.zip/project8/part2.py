import numpy as np
import struct

def float_to_binary(num):
    return ''.join(bin(c).replace('0b', '').rjust(8, '0') for c in struct.pack('!d', num))

def binary_to_float(b):
    bf = int(b, 2).to_bytes(8,'big')  
    return struct.unpack('>d', bf)[0]

def my_laplace(scale=1):
    u = np.random.uniform()
    b = np.random.randint(2)
    l = (2*b-1)*np.log(u)
    return l*scale


# Should return `True` when y is believed to be an output of my_place(scale).
# Otherwise should return `False`
def is_scaled_laplace_img(y, scale):
    if y>0:
        y*=-1

    x = np.exp(y/scale)
#    hi = x + .00000001
#    lo = x - .00000001
#    retval = False
#    testem = np.random.uniform(low=lo, high=hi, size = 10000)
    if(scale*np.log(x) == y):
        return True
    print(type(scale*np.log(x)))


#    for item in testem:
#        if item != x:
#            if(scale*np.log(item) == y):
#                retval = False

    return False

################################################################################
# driver/test code below here. 
################################################################################



# This method will run your implementation fo is_scaled_laplace_img 1000 times
# on unshifted samples, and then 1000 times on shifted samples.
# 
# When completed, this method should output numbers that are as different as
# possible.
def test(): 
    scale = 1.2 # you can try with different scales
    # first, run on unshifted samples
    total_0 = 0
    for i in range(1000):
        l = np.random.laplace(scale=scale) 
        # switch to the line below to test on my_laplace instead
        #l = my_laplace(1.2) 
        if l > 0:
            l = l*-1
        if is_scaled_laplace_img(l,scale):
            total_0 += 1
    print('True outputs on total on unshifted samples: ', total_0) # should be high, ideally 1000

    # second, run on shifted samples
    total_1 = 0
    for i in range(1000):
        l = 1.0 + np.random.laplace(scale=scale) 
        # switch to the line below to test on my_laplace instead
        #l = my_laplace(1.2) 
        if l > 0:
            l = l*-1
        if is_scaled_laplace_img(l,scale):
            total_1 += 1
    print('True outputs on total on shifted samples:   ', total_1) # should be lowe


test()
