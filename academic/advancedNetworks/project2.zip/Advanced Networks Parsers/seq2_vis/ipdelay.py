import math
import statistics
import time
import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

placenames = ["www.amazon.com", "www.cnn.com",  "www.kidshealth.org", "www.walmart.com","www.youtube.com"]

def toTime(n):
    gogo = time.strptime(n, "%H:%M:%S")
    return round(gogo[3]+gogo[4]/60)%24

def avgTwelve(n):
    retlist = np.repeat(0.0,12)
    naten = 0
    average = 0
    for item in n:
        retlist[naten%12] += item 
        naten += 1
    naten = 0

    print(retlist)
    for retval in retlist:
        retlist[naten] = retval/7
        naten+=1
    return retlist

def combinepchar():
    for name in placenames:
        for i in range(1,4):
            write_one = open('1combined_pchar'+str(i)+'_'+name+'_seq2.csv', 'w')

            if(i == 1):
                write_one.write("service,date,time,index,ip,delay,loss\n")
            else:
                write_one.write("service,date,time,index,ip,bw,queuing\n")
            for day in [1,2,3,4,5,6,7,8]:
                read_one = open('pchar'+str(i)+'_'+name+'_seq2_day'+str(day)+'.txt', 'r')
                readlines = read_one.readlines()
                write_one.writelines(readlines)
                read_one.close
            write_one.close

def combinetrace():
    for name in placenames:
        for i in range(1,3):
            write_one = open('1combined_traceroute'+str(i)+'_'+name+'_seq2.csv', 'w')

            if (i == 1):
                write_one.write("service,date,time,index,ip,delay1,delay2,delay3,average\n")
            else:
                write_one.write("service,date,time,count\n")

            for day in [1,2,3,4,5,6,7,8]:
                read_one = open('traceroute'+str(i)+'_'+name+'_seq2_day'+str(day)+'.txt', 'r')
                readlines = read_one.readlines()
                write_one.writelines(readlines)
                read_one.close
            write_one.close


def isEqArr(n, m):
    if(len(n) != len(m)):
        return False
    for i in range(0,len(n)):
        #print(n[i])
        #print(m[i])
        if not (n[i] == m[i]):
            return False
    return True

def plotem():
    enum = 0
    arrayAvg = []
    colors = ["red", "green", "blue", "yellow", "orange", "purple", "teal"]

    website_day = []

    for name in placenames:
        print(name)
        fig = plt.figure()
        ax = fig.add_subplot()
        temp = pd.read_csv("1combined_traceroute2_"+name+"_seq2.csv")
        counts = temp["count"]

        df = pd.read_csv("1combined_traceroute1_"+name+"_seq2.csv")
        
        arrayAtTime = []

        bottom = 0
        distinctArrays = []

                

        for time in counts:
            tempHold = df["ip"][bottom:(bottom+time)].array
            flag = 0
            specific = 0
            for route in distinctArrays:
                if(isEqArr(tempHold,route)):
                    flag = 1
                    break
                else:
                    specific+=1

            if (flag == 0):
                distinctArrays.append(tempHold)
            arrayAtTime.append(specific)
            bottom+=time



        jointArray = distinctArrays[0]

        extras = []
        lengther = len(distinctArrays[0])


        for tempArr in distinctArrays:
            if len(tempArr) == lengther:
                for iterer in range(0,lengther):
                    if jointArray[iterer] == '-1' and tempArr[iterer] != '-1':
                        jointArray[iterer] = tempArr[iterer]


        finArrr = []
        ipLib = {}
        #print(jointArray)
        for iterer in range(0, len(jointArray)):
            if jointArray[iterer] != '-1' and jointArray[iterer] not in finArrr:
                finArrr.append(jointArray[iterer])
                ipLib[jointArray[iterer]] = 0.0

#        print(finArrr)

  #      arrAtHour = np.repeat({}, 24)

        arrAtHour = np.repeat(ipLib.copy(),24)
        repeatsAtHour = np.repeat(ipLib.copy(),24)

        for i in range(0, 24):
            arrAtHour[i] = ipLib.copy()
            repeatsAtHour[i] = ipLib.copy()
#        print(repeatsAtHour[0])



        #print(df['ip'].size)
        for itere in range(0,df['ip'].size):
            if (not (np.isnan(df["average"][itere]))) and (df["ip"][itere] in finArrr):
                ipLib[df["ip"][itere]] += df["average"][itere] 
                arrAtHour[toTime(df["time"][itere])][df["ip"][itere]] += df["average"][itere]
                repeatsAtHour[toTime(df["time"][itere])][df["ip"][itere]] += 1
#                if toTime(df["time"][itere]) == 10.0 and df["ip"][itere] == "(192.170.192.36)":
#                    print(df["average"][itere])
#                print(repeatsAtHour[toTime(df["time"][itere])][df["ip"][itere]])

        arrAtHour[10][finArrr[3]] += 10000


        for hour in range(0,24):
            finLen = []
            ooo = 0
            for object in arrAtHour[hour].keys():
                if repeatsAtHour[hour][object] == 0:
#                    print(hour)
                    finLen.append(0)
                else:
                    finLen.append(arrAtHour[hour][object]/((repeatsAtHour[hour][object])))
            
            print(str(hour) + ":")
            print(arrAtHour[hour])
            ax.plot(finArrr, finLen, alpha = .50, label = str(hour)+":00")
 

        finLen = []
        ooo = 0
        for object in ipLib.keys():
            finLen.append(ipLib[object]/df["ip"].tolist().count(object))
        
        
        listUse = list(ipLib.keys())
        lister = [""]
        for item in listUse:
            lister.append(item)

        ax.scatter(finArrr, finLen, color="black")
        ax.plot(finArrr, finLen, color="black")
        
        secondArr = []
        for item in finLen:
            secondArr.append(item-2)
        

        plt.draw()

        for tick in ax.get_xticklabels():
            tick.set_rotation(45)

        ax.set(xlabel ='IP Address (in order of use)', ylabel ='Latency (ms)', ylim =(0,max(finLen)+max(finLen)/1), title = "Latency by IP for "+name)
        ax.legend(loc=2)


        plt.show()
        #print(distinctArrays)

if __name__ == "__main__":
    combinepchar()
    combinetrace()
    plotem()
#    makeCircle()             
#    weirdplot()
#    hoursLinear()

