import math
import statistics
import time
import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

placenames = ["www.amazon.com", "www.cnn.com", "www.cs.stanford.edu", "www.walmart.com", "www.cs.uchicago.edu", "www.kidshealth.org", "www.nsf.gov", "www.nytimes.com", "www.webmd.com", "www.whitehouse.gov", "www.yelp.com", "www.youtube.com"]

def toTime(n):
    gogo = time.strptime(n, "%H:%M:%S")
    return gogo[3]+gogo[4]/60
def avgTwelve(n):
    retlist = np.repeat(0.0,12)
    naten = 0
    average = 0
    for item in n:
        retlist[naten%12] += item 
        naten += 1
    naten = 0

    print(retlist)
    for retval in retlist:
        retlist[naten] = retval/7
        naten+=1
    return retlist

def combinePing():
    for name in placenames:
        write_one = open('1combined_traceroute1_'+name+'_seq1.csv', 'w')
        write_two = open('1combined_traceroute2_'+name+'_seq1.csv', 'w')
        write_one.write("url,date,time,index,ip,p1,p2,p3,avg\n")
        write_two.write("url,date,time,pingNum\n")
        for day in [1,2,3,4,5,6,8]:
            read_one = open('traceroute1_'+name+'_seq1_day'+str(day)+'.txt', 'r')
            read_two = open('traceroute2_'+name+'_seq1_day'+str(day)+'.txt', 'r')
            readlinesone = read_one.readlines()
            readlinestwo = read_two.readlines()
            write_one.writelines(readlinesone)
            write_two.writelines(readlinestwo)
            read_one.close
            read_two.close
        write_one.close
        write_two.close


def isEqArr(n, m):
    if(len(n) != len(m)):
        return False
    for i in range(0,len(n)):
        #print(n[i])
        #print(m[i])
        if not (n[i] == m[i]):
            return False
    return True

def plotem():
#    plt.axes().set(xlim=(0,24), ylim=(0,50))
    enum = 0
    arrayAvg = []
    colors = ["red", "green", "blue", "yellow", "orange", "purple", "teal"]

    website_day = []

    for name in placenames:
        print(name)
        fig = plt.figure()
        ax = fig.add_subplot()
        temp = pd.read_csv("1combined_traceroute2_"+name+"_seq1.csv")
        counts = temp["pingNum"]

        df = pd.read_csv("1combined_traceroute1_"+name+"_seq1.csv")
        
        arrayAtTime = []

        bottom = 0
        distinctArrays = [[]]
        for time in counts:
            tempHold = df["ip"][bottom:(bottom+time)].array
            flag = 0
            specific = 0
            for route in distinctArrays:
                if(isEqArr(tempHold,route)):
                    flag = 1
                    break
                else:
                    specific+=1

            if (flag == 0):
                distinctArrays.append(tempHold)
            arrayAtTime.append(specific)
                #arrayAtTime.append(specific)
            bottom+=time

        print(distinctArrays)

        def minifunc(n):
            retarr = np.repeat(0,36)
            for i in range(0,12):
                temp = np.repeat((i*2)+1, 3)
                for ii in range(0,3):
                    retarr[i*3 + ii] = temp[ii]
            return retarr

        def addabit(n):
            retarr = np.repeat(0.0,36)
            igg = 0
            for i in range(0,36):
                retarr[i] = n[i] + (i % 3) * .3
            return retarr

        tmmm = minifunc(range(0,11))
#        ax.scatter(np.repeat(tmmm,7),arrayAtTime)
        for i in range(0,7):
            ax.plot(addabit(tmmm),arrayAtTime[i*36:(i+1)*36], label = str(i))
            ax.scatter(addabit(tmmm),arrayAtTime[i*36:(i+1)*36])
        ax.legend()
        ax.set(xlabel ='Hour', ylabel ='Path', xlim =(0, 24), ylim =(1, max(arrayAtTime)+1), title = "Traceroute "+name)
#        plt.show()

        plt.savefig("-tracerouter_"+name+".png")
        plt.close(fig)
        #fig = plt.figure()
        #ax = fig.add_subplot()

#        timed = list(map(toTime, df["time"]))
#        theta = 2 * np.pi * np.random.rand(7)
#
#
#        coloren = []
#        for col in colors:
#            coloren.extend(np.repeat(col, 12))
#
#        print(df["average"])
#        c = ax.scatter(timed, df["average"], c=coloren, s=30, cmap = 'hsv', alpha = .75)
#        m = ax.plot(timed[:12],avgTwelve(df["average"]),"black")
#        
#        for i in range(0,7):
#            o = ax.plot(timed[:12],df["average"][12*i:12*(i+1)],colors[i], linestyle = "solid", alpha = .12)
#
#        ax.set(xlabel ='Hour', ylabel ='Latency (ms)', xlim =(0, 24), ylim =(0, max(df["average"])+5), title =name)
#
#        enum+=1
##        plt.show()
#
#        plt.savefig("-"+name+".png")
#        def percentofavg(n):
#            retlist = np.repeat(0.0, len(n))
#            avg = statistics.mean(n)
#            nater = 0
#            for item in n:
#                retlist[nater] = ((item+1)-(avg+1))/(avg+1)
#                nater+=1
#            return retlist
#
#        def weekavg(n):
#            retarr = np.repeat(0.0,7)  
#            for i in range(0,7):
#                print(n[12*i:12*(1+i)])
#                retarr[i] = statistics.mean(n[12*i:12*(i+1)])
#            return retarr
#
#        website_day.extend(weekavg(df["average"]))
#        arrayAvg.extend(percentofavg(avgTwelve(df["average"])))
#        plt.close(fig)
#
#    print(arrayAvg)
#
#    fig = plt.figure()
#    ax = fig.add_subplot()
#    fincolors = []
#    fintimes = []
#    colors.extend(["maroon", "pink", "lime", "grey", "beige"])
#    times = [1,3,5,7,9,11,13,15,17,19,21,23]
#    for i in range(0,12):
#        fintimes.extend(times)
#        fincolors.extend(np.repeat(colors[i],12))
#    c = ax.scatter(fintimes, arrayAvg, c=fincolors, s=30, cmap = 'hsv', alpha = .12)
#    m = ax.plot(times,avgTwelve(arrayAvg),"black")
#    n = ax.plot(times,np.repeat(0, 12),"grey", linestyle = "dashed")
#    for i in range(0,12):
#        ax.plot(times[:12],arrayAvg[12*i:12*(i+1)],colors[i], linestyle = "solid", alpha = .12)
#    ax.set(xlabel ='Hour', ylabel ='Latency (ms)', xlim =(0, 24), ylim =(-1, 1), title = "Total")
#    
#    plt.savefig("-totalFinal.png")
#    plt.show()
#    plt.close(fig)
#    fig = plt.figure()
#
#    ax = fig.add_subplot()
#    for i in range(0,12):
#        print(website_day[7*i:7*(i+1)])
#        ax.plot(range(1,8),website_day[7*i:7*(i+1)],colors[i], linestyle = "solid", alpha = .8, label = placenames[i])
#
#
#    ax.legend()
#    ax.set(xlabel ='Day of the Week', ylabel ='Latency (ms)', xlim =(1, 7), ylim =(0,80), title = "Daily average Latency, By Website")
#    plt.show()
#    plt.gcf().autofmt_xdate()

def hoursLinear():
    # create data
    y = [ 2,4,6,8,10,12,14,16,18,20 ]
    x = [datetime.datetime.now() + datetime.timedelta(hours=i) for i in range(len(y))]

    # plot
    plt.plot(x,y)
    plt.gcf().autofmt_xdate()
    plt.show()

    # make up some data
    x = [datetime.datetime.now() + datetime.timedelta(hours=i) for i in range(12)]
    y = [i+random.gauss(0,1) for i,_ in enumerate(x)]

    # plot
    plt.plot(x,y)
    # beautify the x-labels
    #plt.gcf().autofmt_xdate()

    plt.show()

if __name__ == "__main__":
    combinePing()
    plotem()
#    makeCircle()             
#    weirdplot()
#    hoursLinear()

