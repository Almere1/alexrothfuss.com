import pandas as pd
import numpy
import sys
import csv
import regex as re
import statistics
import os
from os import path

commands = ['ping', 'traceroute']
services_list = []

ping_header = ["Service", "date", "time", "list of ping delays (for 10 seconds)",
"average ping delay (in 10 seconds)"]

traceroute_header = ["Service", "date", "time", "traceroute hop index",
"IP of hop", "delay1", "delay2", "delay3", "average delay"]

traceroute_header2 = ["Service", "date", "time", "total traceroute hop count"]

rowlist = []
#------------------------------------------------------------------------------#
# Change the header to the path of the raw data files if they are not in the
#    same directory as this file
header = "./"
files = os.listdir(header)
seq1files = [x for x in files if "seq1" in x]

#------------------------------------------------------------------------------#
# Checks if a string has numbers
def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)

# Splits a traceroute line into relevant pieces of data: hop index, IP of hop,
#    the (up to) 3 delays listed, and the average of the delays
def parse_trace(trace_string):
    # Split all elements of the traceroute line
    trace_line = trace_string.strip().split(" ")
    #print("traceline: ")
    #print(trace_line)

    # Traceroute hop index
    index = trace_line.pop(0)
    #print(trace_line)

    #No response -- * * * *
    if len(trace_line) == 4:
        ip = delay1 = delay2 = delay3 = avg = "-1"

    else:
        #print(trace_line)

        # Match the first IP address of the line
        regex_ip = r"^\((?:[0-9]{1,3}\.){3}[0-9]{1,3}\)$"
        ip = [x for x in trace_line if re.match(regex_ip, x)][0]
        #print(ip)

        # Match any timestamps or '*' (denoting no response; assign placeholder)
        regex_time = r"[0-9]*(\.[0-9]+)$"
        times = [x for x in trace_line if re.match(regex_time, x) or x == "*"]
        delays = [float(x.strip()) if hasNumbers(x) else "None" for x in times]
        #print(delays)

        delay1 = delays[0]
        delay2 = delays[1]
        delay3 = delays[2]
        avg = numpy.mean([x for x in delays if type(x) != str])

    return (index, ip, delay1, delay2, delay3, avg)

#------------------------------------------------------------------------------#
#                                 SEQUENCE 1                                   #
#------------------------------------------------------------------------------#

def readfile(file_name):
    ping_dicts = []
    trace_dicts = []
    trace_dicts2 = []
    inner_trace_dicts = []
    with open(file_name, 'rt') as myfile:
        comm_type = None
        service = None
        for myline in myfile:
            if 'Service' in myline:
                #Retrieve name of service
                service = myline.split(" ")[1].strip()
                comm_type = None
                if service not in services_list:
                    services_list.append(service)

            elif 'Sleep' in myline:
                continue

            elif 'Round' in myline:
                continue

            elif 'starts' in myline:
                # Retrieve date, time, and command type
                cmd_info = myline.split("starts: ")
                comm_type = cmd_info[0].split(" ")[0].lower()
                #print(comm_type)

                dt_info = re.sub('[()]', '', cmd_info[1]).strip()[1:-1].split(" ")
                #print(dt_info)
                date = dt_info[0]
                time = dt_info[1]
                #print(date, time)

                # Reset any variables not related to the overall ping dictionary
                ping = ""
                ping_ttl = []
                inner_trace_dicts = []

            elif 'Ping ends' in myline:
                # Format for csv
                ping = ping[:-1]
                dict1 = {"Service": service, "date": date, "time":time,
                "list of ping delays (for 10 seconds)": ping,
                "average ping delay (in 10 seconds)":avg}

                # Push line to final table
                ping_dicts.append(dict1)

            #------ PING ------#
            elif (comm_type == "ping"):
                #print(myline)
                if 'ping' in myline:
                    continue

                elif "time=" in myline:
                    #Parse ICMP packet response
                    s = myline.split("time=")
                    ping_time = float(s[1].split(" ")[0])
                    ping += str(ping_time) + "|"
                    ping_ttl.append(ping_time)

                elif "rtt" in myline:
                    avg = numpy.mean(ping_ttl)

            #------ TRACEROUTE ------#
            elif (comm_type == 'traceroute'):
                if 'ends:' in myline:
                    continue
                elif 'Repeat' in myline:
                    continue

                elif 'traceroute to' in myline:
                    ip = myline.split(" ")[3][:-1]
                    #print("IP: " + ip)

                elif 'traceroute' in myline:
                    continue

                elif hasNumbers(myline):
                    #print(myline)
                    stats = parse_trace(myline)
                    dict_row = {"Service": service, "date": date, "time": time,
                    "traceroute hop index": stats[0], "IP of hop": stats[1],
                    "delay1": stats[2], "delay2": stats[3], "delay3": stats[4],
                    "average delay": stats[5]}
                    inner_trace_dicts.append(dict_row)

                    if ip and ip in myline:
                        # View most recent hop
                        max_hop = stats[0]
                        #print(max_hop)
                        dict_row = {"Service": service, "date": date,
                            "time": time, "total traceroute hop count": max_hop}
                        trace_dicts2.append(dict_row)
                        trace_dicts = trace_dicts + inner_trace_dicts

    # Convert lists to appropriate dataframes
    ping_df = pd.DataFrame(columns = ping_header, data = ping_dicts)
    trace_df = pd.DataFrame(columns = traceroute_header, data = trace_dicts)
    trace_maxhops_df = pd.DataFrame(columns = traceroute_header2, data = trace_dicts2)


    for service in services_list:
        day = file_name.replace("./raw_data/", "").split('_')[2].strip()

        ping_csv_name = "test_clean/seq1/ping_" + service + "_seq1_" + day
        trace_csv_name1 = "test_clean/seq1/traceroute1_" + service + "_seq1_" + day
        trace_csv_name2 = "test_clean/seq1/traceroute2_" + service + "_seq1_" + day
        #print(ping_csv_name)
        ping_service_df = ping_df[ping_df["Service"] == service]
        ping_service_df.to_csv(ping_csv_name, header= False, index= False)

        trace_service_df = trace_df[trace_df["Service"] == service]
        trace_service_df.to_csv(trace_csv_name1, header= False, index= False)
        text = open(trace_csv_name1, "r")
        #print(text)
        text = ''.join([i for i in text]).replace(",None", "")
        x = open(trace_csv_name1,"w")
        x.writelines(text)
        x.close()

        trace_maxhops_service_df = trace_maxhops_df[trace_maxhops_df["Service"] == service]
        trace_maxhops_service_df.to_csv(trace_csv_name2, header= False, index= False)

#------------------------------------------------------------------------------#

for file in seq1files:
    #print(f)
    file_name = header + file
    readfile(file_name)
