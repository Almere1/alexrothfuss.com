import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
from os import path
import sys
import csv

# Get a list of all the files in the directory
header = "./api"
files = os.listdir(header)

header = "./ping"
ping_files = os.listdir(header)
#print(files)

#### Dataframe setup
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

header = ["Service", "IP", "API call", "Date", "Time", "Name lookup", "Connect time", "App Connect time", "Pretransfer", "Redirect", "Start Transfer", "Total Time"]

ping_header = ["Service", "IP", "Date", "Time", "List of Ping Times", "Avg Ping"]

services = ["www.amazon.com", "www.walmart.com", "www.youtube.com", "www.yelp.com", "cs.stanford.edu"]

nice_colors = ['autumn', 'winter' , 'spring', 'Blues_r']


def make_plot(service_num, graphtype_num):
    current_api_files = [x for x in files if services[service_num] in x]
    current_ping_files = [x for x in ping_files if services[service_num] in x]

    #print(current_service_files)

    #current_service_files = ['api_www.amazon.com_huiying_seq3_day6.csv']

    all_days_api = []
    all_days_ping = []


    for file in current_api_files:
        filename = "./api/" + file
        with open(filename, newline='') as f:
            reader = csv.reader(f)
            data = list(reader)
        all_days_api += data
    #print(all_days_api)

    for file in current_ping_files:
        filename = "./ping/" + file
        with open(filename, newline='') as f:
            reader = csv.reader(f)
            data2 = list(reader)
        all_days_ping += data2


    df = pd.DataFrame(all_days_api, columns = header)
    df["Date Time"] = pd.to_datetime(df["Date"] + ' ' + df["Time"])


    for i in df.columns:
        if i == "Date Time" or i == "Date" or i == "Time":
            continue
        else:
            df[i] = pd.to_numeric(df[i], errors = 'coerce')

    print(df.dtypes)

    df1 = df[["Date Time", "Name lookup", "Connect time",
                "App Connect time", "Pretransfer", "Redirect", "Start Transfer", "Total Time"]]
    df1 = df1.sort_values(by=['Date Time'])

    df1b = df1[["Date Time", "Total Time"]]

    ping_df = pd.DataFrame(all_days_ping, columns = ping_header)
    ping_df["Avg Ping"] = pd.to_numeric(ping_df["Avg Ping"], errors = 'coerce')

    ping_df["Date Time"] = pd.to_datetime(ping_df["Date"] + ' ' + ping_df["Time"])

    ping_df1 = ping_df[["Date Time", "Avg Ping"]]
    ping_df1 = ping_df1.sort_values(by=['Date Time'])


    if graphtype_num == 0: #All API curl measurements in graph, week overview

        ax = df1.plot.area(x = 'Date Time', stacked = False, colormap = "Blues_r");
        ping_df1.plot.line(ax = ax, x = "Date Time", color = 'red');
        df1b.plot.line(ax = ax, x = "Date Time", color = 'blue')

        title = 'Total API call vs Ping Latency from 4/29 to 5/6/21 for ' + services[service_num]
        ax.set_title(title)

        ax.set_ylabel("Command Latency (ms)")
        plt.legend()
        plt.show()


    #====================================================================
    elif graphtype_num == 1: #Average total API latency and ping latency, week overview
        df2 = df1.resample('H', on = 'Date Time')["Total Time"].mean()
        #print(df2)
        ping_df2 = ping_df1.resample('H', on = 'Date Time')["Avg Ping"].mean()

        ax = df2.plot.line(x = 'Date Time', color = 'blue')
        ping_df2.plot.line(ax = ax, x = 'Date Time', color = 'red')
        title = 'Total API call vs Ping Latency (in ms) by hour from 4/29 to 5/6/21 for ' + services[service_num]
        ax.set_title(title)
        ax.set_ylabel("Command Latency (ms)")
        plt.legend()
        plt.show()

    #====================================================================
    elif graphtype_num == 2: #Average total API latency and ping latency
        colors = ["#004c6d", "#296080", "#437594", "#5d8ba9", "#75a1be", "#8eb8d3", "#a7cfe9", "#c1e7ff"]

        ping_colors = ["#ff0000", "#ff5017", "#ff7430", "#ff914c", "#ffaa6b", "#ffc28d", "#ffd8b2", "#ffedd9"]
        #df.groupby(['Month','Year']).mean().unstack().plot()


        df3 = df[["Date Time", "Total Time"]]
        df3["Hour"] = df3["Date Time"].dt.hour
        df3["Day"] = df3["Date Time"].dt.day
        df3 = df3.set_index('Date Time')

        grouped_avg_daily = df3.groupby(["Hour"])["Total Time"].mean()

        ping_df3 = ping_df1[["Date Time", "Avg Ping"]]
        ping_df3["Hour"] = ping_df3["Date Time"].dt.hour
        ping_df3["Day"] = ping_df3["Date Time"].dt.day
        ping_df3 = ping_df3.set_index('Date Time')

        ping_grouped = ping_df3.groupby(["Hour"])["Avg Ping"].mean()

        #print(df3)
        #print(ping_df3)


        data_by_day = df3.resample('H').mean().set_index(['Day', 'Hour']).unstack('Day')
        ax1 = data_by_day['Total Time'].plot(cmap = 'Blues_r')
        pingdata_by_day = ping_df3.resample('H').mean().set_index(['Day', 'Hour']).unstack('Day')
        pingdata_by_day['Avg Ping'].plot(ax = ax1, cmap = 'autumn')

        grouped_avg_daily.plot(ax = ax1, color = 'b')
        ping_grouped.plot(ax = ax1, color = 'r')
        title = 'Total API call vs Ping Latency hourly view from 4/29 to 5/6/21 for ' + services[service_num]
        ax1.set_title(title)
        ax1.set_ylabel("Command Latency (ms)")
        ax1.get_legend().remove()
        #plt.show()

        grouped_avg_daily.name = services[service_num]
        ping_grouped.name = services[service_num]
        return (grouped_avg_daily, ping_grouped)
        #return(df3['Total Time'], ping_df3['Avg Ping'])
    elif graphtype_num == 3:


        df3 = df[["Date Time", "Total Time"]]
        df3["Hour"] = df3["Date Time"].dt.hour
        df3["Day"] = df3["Date Time"].dt.day
        df3 = df3.set_index('Date Time')

        grouped_avg_daily = df3.groupby(["Hour"])["Total Time"].mean()

        ping_df3 = ping_df1[["Date Time", "Avg Ping"]]
        ping_df3["Hour"] = ping_df3["Date Time"].dt.hour
        ping_df3["Day"] = ping_df3["Date Time"].dt.day
        ping_df3 = ping_df3.set_index('Date Time')

        ping_grouped = ping_df3.groupby(["Hour"])["Avg Ping"].mean()

        grouped_avg_daily.name = services[service_num]
        ping_grouped.name = services[service_num]
        return (grouped_avg_daily, ping_grouped)



#make_plot(0, 2)

def make_big_plot():
    colors = ["#004c6d", "#296080", "#437594", "#5d8ba9", "#75a1be", "#8eb8d3", "#a7cfe9", "#c1e7ff"]

    ping_colors = ["#ff0000", "#ff5017", "#ff7430", "#ff914c", "#ffaa6b", "#ffc28d", "#ffd8b2", "#ffedd9"]

    api_df = pd.DataFrame()
    ping_df = pd.DataFrame()
    ax = plt.gca()
    for i in range(len(services)):

        oof = make_plot(i, 3)
        #print(oof[0])
        #print(oof[2])
        api_info = oof[0]
        ping_info = oof[1]


        api_df = pd.concat([api_df, api_info], axis = 1)
        ping_df = pd.concat([ping_df, ping_info], axis = 1)

        api_info.plot(ax = ax, color = colors[i + 1])
        ping_info.plot(ax = ax, color = ping_colors[i + 1])

    api_df['Average'] = api_df.mean(numeric_only = True, axis = 1)
    ping_df['Average'] = ping_df.mean(numeric_only = True, axis = 1)

    #print(api_df)
    #print(ping_df)

    api_df['Average'].plot(ax = ax, color = 'b')
    ping_df['Average'].plot(ax = ax, color = 'r')

    title = 'Total API call vs Ping Latency hourly view from 4/29 to 5/6/21 for all services'
    ax.set_title(title)
    ax.set_ylabel("Command Latency (ms)")
    plt.legend()
    plt.show()

make_big_plot()
