import math
import statistics
import time
import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

placenames = ["www.amazon.com", "www.walmart.com", "www.youtube.com", "www.yelp.com", "cs.stanford.edu"]

def toTime(n):
    gogo = time.strptime(n, "%H:%M:%S")
    return round(gogo[3]+gogo[4]/60)

#Takes the set of all pings, and condenses them into two files.
def combinePing():
    for name in placenames:
	 
    # 
    #First combined file, uses initial set of data
    #
    
        write_one = open('1combined_ping_'+name+'_seq3.csv', 'w')
        write_one.write("url,ip,api,date,time,p1,p2,p3,p4,p5,p6,average\n")
        for day in [1,2,3,4,5,6,7,8]:
            read_one = open('api/api_'+name+'_huiying_seq3_day'+str(day)+'.csv', 'r')
            readlines = read_one.readlines()
            write_one.writelines(readlines)
            read_one.close
        write_one.close
    #
    #Second combined file, uses self-produced set of data
    #
    
        write_one = open('2combined_ping_'+name+'_seq3.csv', 'w')
        write_one.write("url,ip,api,date,time,p1,p2,p3,p4,p5,p6,average\n")
        for day in [9,10,11, 12]:
            read_one = open('api/api_'+name+'_huiying_seq3_day'+str(day)+'.csv', 'r')
            readlines = read_one.readlines()
            write_one.writelines(readlines)
            read_one.close
        write_one.close


def plotem():
#    plt.axes().set(xlim=(0,24), ylim=(0,50))
    enum = 0
    arrayAvg = []
    colors = ["red", "green", "blue", "yellow", "orange", "purple", "teal"]

    website_day = []

    #
    #Plots every unique website used
    #
    
    for name in placenames:
    
        #
        # Reads the files and initializes the plots
        #
        
        fig = plt.figure()
        ax = fig.add_subplot()
        df = pd.read_csv("1combined_ping_"+name+"_seq3.csv")
        df_two = pd.read_csv("2combined_ping_"+name+"_seq3.csv")
        dg = pd.read_csv(name+"_predictions_api.csv")
        
        #
        #Produces a list of the hours when data was taken
        #
        
        timed = list(map(toTime, df["time"]))
        timed_two = list(map(toTime, df_two["time"]))


        averageHour = np.repeat(0.0,24)
        averageHourTwo = np.repeat(0.0,24)

        #
        #Adds all datapoints to 24-item lists corresponding with the time where the data was taken
        #

        for itere in range(0,len(timed)):
            averageHour[timed[itere]] += df["average"][itere]    
        for itere in range(0,len(timed_two)):
            averageHourTwo[timed_two[itere]] += df_two["average"][itere]    

        #
        #Averages each hour, and combines the two datasets, by dividing the dataset by the number of datapoints
        #
        
        for itere in range(0,24):
            print(timed.count(itere))
            print(timed_two.count(itere))

            averageHour[itere] = (averageHour[itere] + (averageHourTwo[itere]))/((timed.count(itere) + timed_two.count(itere)))


        print(averageHourTwo)


        #pointless I think, but i'm not gonna find out
        timed_two = list(map(round,dg["0"]))

         

        
        print(name)
        print(averageHour)

        #
        #Produces the plot files
        #
        ax.scatter(dg["0"], dg["1"])
        ax.plot(averageHour)
        ax.set(xlabel ='Hour', ylabel ='Latency (ms)', xlim =(0, 24), title ="Average Latency vs Predicted Latency for\nAPI call for " + name)
        plt.savefig("+"+name+".png")
        plt.close(fig)



if __name__ == "__main__":
    combinePing()
    plotem()
