import math
import statistics
import time
import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

placenames = ["www.amazon.com", "www.walmart.com", "www.youtube.com", "www.yelp.com", "cs.stanford.edu"]

def toTime(n):
    gogo = time.strptime(n, "%H:%M:%S")
    return round(gogo[3]+gogo[4]/60)


def combinePing():
    for name in placenames:
        write_one = open('1combined_ping_'+name+'_seq3.csv', 'w')
        write_one.write("url,ip,date,time,times,average\n")
        for day in [1,2,3,4,5,6,7,8]:
            read_one = open('ping/ping_'+name+'_huiying_seq3_day'+str(day)+'.csv', 'r')
            readlines = read_one.readlines()
            write_one.writelines(readlines)
            read_one.close
        write_one.close

        write_one = open('2combined_ping_'+name+'_seq3.csv', 'w')
        write_one.write("url,ip,date,time,times,average\n")
        for day in [9,10,11,12]:
            read_one = open('ping/ping_'+name+'_huiying_seq3_day'+str(day)+'.csv', 'r')
            readlines = read_one.readlines()
            write_one.writelines(readlines)
            read_one.close
        write_one.close


def plotem():
    enum = 0
    arrayAvg = []
    colors = ["red", "green", "blue", "yellow", "orange", "purple", "teal"]

    website_day = []

    for name in placenames:
        fig = plt.figure()
        ax = fig.add_subplot()
        df = pd.read_csv("1combined_ping_"+name+"_seq3.csv")
        df_two = pd.read_csv("2combined_ping_"+name+"_seq3.csv")
        dg = pd.read_csv(name+"_predictions_ping.csv")

        timed = list(map(toTime, df["time"]))
        timed_two = list(map(toTime, df_two["time"]))


        averageHour = np.repeat(0.0,24)
        averageHourTwo = np.repeat(0.0,24)

        for itere in range(0,len(timed)):
            averageHour[timed[itere]] += df["average"][itere]
        for itere in range(0,len(timed_two)):
            averageHourTwo[timed_two[itere]] += df_two["average"][itere]




        for itere in range(0,24):
            print(timed.count(itere))
            print(timed_two.count(itere))

            averageHour[itere] = (averageHour[itere] + (averageHourTwo[itere]))/((timed.count(itere) + timed_two.count(itere)))


        print(averageHourTwo)



        timed_two = list(map(round,dg["1"]))


        ax.scatter(dg["1"], dg["2"])

        print(name)
        print(averageHour)

        ax.plot(averageHour)
        ax.set(xlabel ='Hour', ylabel ='Latency (ms)', xlim =(0, 24), title ="Average Latency vs Predicted Latency for\nPing of " + name)

        plt.savefig("-"+name+".png")
        plt.close(fig)



if __name__ == "__main__":
    combinePing()
    plotem()
