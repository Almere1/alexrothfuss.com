import pandas as pd







#def hashit(List, IPList):
#    goto = List.split(" ")
#    hashing = {}
#    i = 0
#    for ip in IPList.split(" "):
#        hashing[ip] = goto[i]
#        i+=1
#    return hashing
#
#def main():
#
#
#    callList = "https://www.youtube.com/results?search_query=keyword https://www.yelp.com/search?find_desc=%3Ckeyword%3E&find_loc=Chicago%2C+IL https://www.amazon.com/s?k=keyword&ref=nb_sb_noss_2 https://www.walmart.com/search/?query=%3Ckeyword%3E https://cs.stanford.edu/search/node/keyword"
#
#    ipCall = "216.58.192.142 151.101.52.116 205.251.242.103 161.170.230.170 171.64.64.64"
#
#
#    WebListOne=("yelp.com youtube.com cnn.com nytimes.com kidshealth.org webmd.com cs.uchicago.edu cs.stanford.edu whitehouse.gov https://www.nsf.gov/ amazon.com walmart.com")
#    WebListOneIP=("151.101.52.116 216.58.192.142 151.101.193.67 151.101.129.164 192.234.249.117 207.231.204.56 128.135.164.125 171.64.64.64 104.70.144.123 128.150.4.107 205.251.242.103 161.170.230.170")
#    WebHashOne = hashit(WebListOne, WebListOneIP)
#    WebHashThree = hashit(callList, ipCall)
#
#
#    listemPing1 = []
#    listemTrace1 = []
#    listemTraceTotal1 = []
#    read_one = open('seq1_akrothfuss.txt', 'r')
#
#
#    readlines = read_one.readlines()
#    date = time = "Not"
#


#-----------------------------------------------------------#
#                      SEQUENCE 3                           #
#-----------------------------------------------------------#

def main():
    for dayNum in range(1, 5):
        read_three = open('../raw_data/maggie_zhao_seq3_day'+str(dayNum)+'.txt', 'r')
        readlines = read_three.readlines()

        write_three_api = "huiying_seq3"
        write_three_ping = "huiying_seq3"

        ip_flag = 0
        track = 6
        url = ""
        api_call = ""
        output = ""
        date_time = ""
        arr_ping = []

        for line in readlines:
            if (track == 6):
                if "API call https://" in line:
                    api_call = line[line.find("https://"):line.find("\n")]
                    url = api_call [8:]
                    url = url[:url.find("/")]
                    track = 0
                    output = url

            elif ((track % 2) == 0):
                if "API call starts:" in line:
                    date_time = line[line.find("[")+1:line.find("]")].replace(" ", ",")
                elif "remote_ip:" in line:
                    output = output + "," + line[21:line.find("\n")] + "," + api_call + "," + date_time
                    ip_flag = 1
                elif ":" in line and (ip_flag == 1):
                    temp = line[21:]
                    temp = temp[:temp.find("s")]
                    output = output + "," + str(float(temp)*1000)
                    if "time_total" in line:
                        writem = open("clean_data/api/api_"+url+"_"+write_three_api+"_day"+str(dayNum+8)+".csv", "a")
                        writem.write(output+'\n')
                        ip_flag = 0
                        output = url
                        track+=1
            else:
                if "ping -w 10" in line:
                    output = output + "," + line[11:line.find("\n")]
                elif "Ping starts" in line:
                    output = output + "," + line[line.find("[")+1:line.find("]")].replace(" ", ",")
                elif "bytes from" in line:
                    arr_ping.append(float(line[line.find("time=")+5:line.find(" ms")]))
                elif "ping statistics" in line:
                    temp = ""
                    output = output + ","
                    for time in arr_ping:
                        temp = temp + "|" + str(time)
                    temp = temp[1:]
                    output = output + temp + "," + str(sum(arr_ping)/len(arr_ping))
                    #print(output)
                    writem = open("clean_data/ping/ping_"+url + "_" + write_three_ping+"_day"+str(dayNum+8)+".csv", "a")
                    writem.write(output+"\n")
                    arr_ping = []
                    output = url
                    track+=1


    read_three.close()

#-----------------------------------------------------------#
#                      DATATYPES                            #
#-----------------------------------------------------------#
#
# I elected to create a unique file for different datatypes
# as well, since otherwise it'll give pandas issues, and
# it'll be difficult to read
#
#    for service in WebListOneIP.split(" "):
#        write_one = open('seq1_'+WebHashOne[service]+"_ping.csv", 'w')
#        write_two = open('seq1_'+WebHashOne[service]+"_trace.csv", 'w')
#        write_three = open('seq1_'+WebHashOne[service]+"_traceTotal.csv", 'w')
#
#        temp = []
#        for item in listemPing1:
#            if service in item[0]:
#            temp.append(item)
#
#        write_one = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Ping Delays", "Average Ping Delay"])
#        write_one.to_csv('seq1_'+WebHashOne[service]+"_ping.csv", index=False, na_rep='Unknown')
#
#
#        temp = []
#        for item in listemTrace1:
#            if service in item[0]:
#            temp.append(item)
#
#        write_two = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Index", "Hop IP", "Delay1", "Delay2", "Delay3", "Average Ping Delay"])
#        write_two.to_csv('seq1_'+WebHashOne[service]+"_trace.csv", index=False, na_rep='Unknown')
#
#        temp = []
#        for item in listemTraceTotal1:
#            if service in item[0]:
#            temp.append(item)
#
#        write_three = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Total Count"])
#        write_three.to_csv('seq1_'+WebHashOne[service]+"_traceTotal.csv", index=False, na_rep='Unknown')
#
#        write_three.close()
#        write_two.close()
#        write_one.close()
#
#
#    for service in ipCall.split(" "):
#        write_one = open('seq3_'+WebHashThree[service]+"_ping.csv", 'w')
#        write_two = open('seq3_'+WebHashOne[service]+"_APICall.csv", 'w')
#
#        temp = []
#        for item in listemPing1:
#            if service in item[0]:
#            temp.append(item)
#
#        write_one = pd.DataFrame(temp, columns=['Service', "Date", "Time", "Ping Delays", "Average Ping Delay"])
#        write_one.to_csv('seq3_'+WebHashOne[service]+"_ping.csv", index=False, na_rep='Unknown')
#
#        temp = []
#        for item in listemTraceTotal1:
#            if service in item[0]:
#            temp.append(item)
#
#        write_two = pd.DataFrame(temp, columns=['Service', "Date", "Time", "End-to-End Delay"])
#        write_two.to_csv('seq3_'+WebHashOne[service]+"_traceTotal.csv", index=False, na_rep='Unknown')
#
#        write_two.close()
#        write_one.close()
#
#    for item in listemPing1:
#        print(item)
#    for item in listemTrace1:
#        print(item)
#    for item in listemPing3:
#        print(item)
#    for item in listemAPI3:
#        print(item)


if __name__ == "__main__":
    main();
