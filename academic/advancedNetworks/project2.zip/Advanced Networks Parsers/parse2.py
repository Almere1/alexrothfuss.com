import pandas as pd
import numpy
import sys
import csv
import regex as re
import statistics
import os
from os import path

commands = ['ping', 'traceroute']
services_list = []


ping_header = ["Service", "date", "time", "list of ping delays (for 10 seconds)",
"average ping delay (in 10 seconds)"]

traceroute_header = ["Service", "date", "time", "traceroute hop index",
"IP of hop", "delay1", "delay2", "delay3", "average delay"]

traceroute_header2 = ["Service", "date", "time", "total traceroute hop count"]

pchar_header = ["Service", "date", "time", "pchar hop index", "IP of hop",
"delay(rtt) at hop", "package loss at hop"]

pchar_header2 = ["Service", "date", "time", "pchar hop index", "IP of hop",
"bw per hop", "queuing per hop"]

#------------------------------------------------------------------------------#
# Change the header to the path of the raw data files if they are not in the
#    same directory as this file
header = "./"
files = os.listdir(header)
seq2files = [x for x in files if "seq2" in x]

#------------------------------------------------------------------------------#
# Checks if a string has numbers
def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)

# Splits a traceroute line into relevant pieces of data: hop index, IP of hop,
#    the (up to) 3 delays listed, and the average of the delays
def parse_trace(trace_string):
    # Split all elements of the traceroute line
    trace_line = trace_string.strip().split(" ")
    #print("traceline: ")
    #print(trace_line)

    # Traceroute hop index
    index = trace_line.pop(0)

    #No response -- * * * *
    if len(trace_line) == 4:
        ip = delay1 = delay2 = delay3 = avg = "-1"

    else:
        #print(trace_line)

        regex_ip = r"^\((?:[0-9]{1,3}\.){3}[0-9]{1,3}\)$"
        ip = [x for x in trace_line if re.match(regex_ip, x)][0]
        #print(ip)

        # Match any timestamps or '*' (denoting no response; assign placeholder)
        regex_time = r"[0-9]*(\.[0-9]+)$"
        times = [x for x in trace_line if re.match(regex_time, x) or x == "*"]
        delays = [float(x.strip()) if hasNumbers(x) else "None" for x in times]
        #print(delays)

        delay1 = delays[0]
        delay2 = delays[1]
        delay3 = delays[2]
        #avg = (sum(delays) + (3 - sum(len_delays))) / sum(len_delays)
        avg = numpy.mean([x for x in delays if type(x) != str])

    return (index, ip, delay1, delay2, delay3, avg)

#------------------------------------------------------------------------------#
#                                 SEQUENCE 2                                   #
#------------------------------------------------------------------------------#

def readfile(file_name):
    comm_type = None
    service = None

    ping_dicts = []
    trace_dicts = []
    trace_dicts2 = []
    inner_trace_dicts = []

    pchar_dicts = []
    pchar_dicts2 = []
    pchar_dicts3 = []
    delay = loss = bw = queueing = -1

    with open(file_name, 'rt') as myfile:
        for myline in myfile:
            if 'Service' in myline:
                #Retrieve name of service
                service = myline.split(" ")[1].strip()
                comm_type = None

            elif 'Sleep' in myline:
                continue

            elif 'Round' in myline:
                continue

            elif 'starts' in myline:
                # Retrieve date, time, and command type
                cmd_info = myline.split("starts: ")
                comm_type = cmd_info[0].split(" ")[0].lower()
                #print(comm_type)

                dt_info = re.sub('[()]', '', cmd_info[1]).strip()[1:-1].split(" ")
                #print(dt_info)
                date = dt_info[0]
                time = dt_info[1]
                #print(date, time)

                # Reset any variables not related to the overall ping dictionary
                ping = ""
                ping_ttl = []
                inner_trace_dicts = []

            #------ PING ------#
            elif 'Ping ends' in myline:
                # Format for csv
                ping = ping[:-1]
                dict1 = {"Service": service, "date": date, "time": time,
                "list of ping delays (for 10 seconds)": ping,
                "average ping delay (in 10 seconds)": avg}

                # Push line to final table
                ping_dicts.append(dict1)
                comm_type = None

            elif (comm_type == "ping"):
                #print(myline)
                if 'ping' in myline:
                    continue

                elif "time=" in myline:
                    #Parse ICMP packet response
                    s = myline.split("time=")
                    ping_time = float(s[1].split(" ")[0])
                    ping += str(ping_time) + "|"
                    ping_ttl.append(ping_time)

                elif "rtt" in myline:
                    avg = numpy.mean(ping_ttl)

            #------ TRACEROUTE ------#
            elif (comm_type == 'traceroute'):
                if 'ends:' in myline:
                    continue
                elif 'Repeat' in myline:
                    continue

                elif 'traceroute to' in myline:
                    ip = myline.split(" ")[3][:-1]
                    #print("IP: " + ip)

                elif 'traceroute' in myline:
                    continue

                elif hasNumbers(myline):
                    #print(myline)
                    stats = parse_trace(myline)
                    #print(stats)
                    dict_row = {"Service": service, "date": date, "time": time,
                    "traceroute hop index": stats[0], "IP of hop": stats[1],
                    "delay1": stats[2], "delay2": stats[3], "delay3": stats[4],
                    "average delay": stats[5]}
                    #print(dict_row)
                    inner_trace_dicts.append(dict_row)

                    if ip and ip in myline:
                        # View most recent hop
                        max_hop = stats[0]
                        #print(max_hop)
                        dict_row = {"Service": service, "date": date,
                            "time": time, "total traceroute hop count": max_hop}
                        trace_dicts2.append(dict_row)
                        trace_dicts = trace_dicts + inner_trace_dicts
                        comm_type = None

            #------ PCHAR ------#
            elif (comm_type == 'pchar'):

                n = re.match("^\s?(\d+):", myline)
                if n:
                    hop_index = (n.group(1))
                    #ip = re.sub('[()]', '', myline.split(" ")[1]).strip()
                    ip = myline[3:].split("(")[0].strip().split(" ")[0]
                    #print(ip)

                    #push to dict
                    dict1 = {"Service": service, "date": date, "time": time,
                    "pchar hop index" : hop_index, "IP of hop" : ip,
                    "delay(rtt) at hop": delay, "package loss at hop": loss }

                    dict2 = {"Service": service, "date": date, "time": time,
                    "pchar hop index" : hop_index, "IP of hop" : ip,
                    "bw per hop" : bw, "queuing per hop": queueing}

                    pchar_dicts.append(dict1)
                    pchar_dicts2.append(dict2)

                    if (ip == target_ip):
                        pchar_dicts3.append(dict2)

                    delay = loss = bw = queueing = "-1"

                elif "pchar to" in myline:
                    target_ip = myline.split(" ")[2]

                elif "Hop char" in myline:
                    rtt_str = myline.split("rtt = ")[1].strip()
                    delay = rtt_str.split(" ")[0].strip()

                    bw_str = myline.split("bw =")[1].strip()
                    bw = bw_str.split(" ")[0].strip()

                elif "Partial loss" in myline:
                    loss = myline.split("(")[1].strip()[:-2]
                    #print(loss)

                elif "Hop queueing" in myline:
                    times2 = [x for x in myline.split(" ") if hasNumbers(x)]
                    queueing = float(times2[0])


    day = file_name.replace("./raw_data/", "").split('_')[2].strip()

    ping_csv_name = "test_clean/seq2/ping_" + service + "_seq2_" + day + ".txt"
    trace_csv_name1 = "test_clean/seq2/traceroute1_" + service + "_seq2_" + day + ".txt"
    trace_csv_name2 = "test_clean/seq2/traceroute2_" + service + "_seq2_" + day + ".txt"
    pchar_csv_name1 = "test_clean/seq2/pchar1_" + service + "_seq2_" + day + ".txt"
    pchar_csv_name2 = "test_clean/seq2/pchar2_" + service + "_seq2_" + day + ".txt"
    pchar_csv_name3 = "test_clean/seq2/pchar3_" + service + "_seq2_" + day + ".txt"


    ping_df = pd.DataFrame(columns = ping_header, data = ping_dicts)
    ping_df.to_csv(ping_csv_name, header= False, index= False)

    trace_df = pd.DataFrame(columns = traceroute_header, data = trace_dicts)
    trace_df.to_csv(trace_csv_name1, header= False, index= False)
    text = open(trace_csv_name1, "r")
    #print(text)
    text = ''.join([i for i in text]).replace(",None", "")
    x = open(trace_csv_name1,"w")
    x.writelines(text)
    x.close()

    trace_maxhops_df = pd.DataFrame(columns = traceroute_header2, data = trace_dicts2)
    trace_maxhops_df.to_csv(trace_csv_name2, header= False, index= False)

    pchar_df = pd.DataFrame(columns = pchar_header, data = pchar_dicts)
    pchar_df.to_csv(pchar_csv_name1, header= False, index= False)

    pchar_df2 = pd.DataFrame(columns = pchar_header2, data = pchar_dicts2)
    pchar_df2.to_csv(pchar_csv_name2, header= False, index= False)

    pchar_df3 = pd.DataFrame(columns = pchar_header2, data = pchar_dicts3)
    pchar_df3.to_csv(pchar_csv_name3, header= False, index= False)

#------------------------------------------------------------------------------#

for file in seq2files:
    #print(file)
    file_name = header + file
    readfile(file_name)
