import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
from os import path
import sys
import csv
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import time

def toTime(n):
    gogo = time.strptime(n, "%H:%M:%S")
    return gogo[3]+gogo[4]/60

def get_mae(max_leaf_nodes, train_X, val_X, train_y, val_y, num, _api):
    services = ["www.amazon.com", "www.walmart.com", "www.youtube.com", "www.yelp.com", "cs.stanford.edu"]
    model = DecisionTreeRegressor(max_leaf_nodes = max_leaf_nodes, random_state = 1)
    model.fit(train_X, train_y)
    preds_val = model.predict(val_X)
    #print(preds_val)
    mae = mean_absolute_error(val_y, preds_val)
    #print(mae)
    make_list = []
    #print(val_X)

    x_values = val_X.values.tolist()
    #print(x_values)
    for i in range(len(preds_val)):

        temp = [x for x in x_values[i]] + [preds_val[i]]
        make_list.append(temp)

    df = pd.DataFrame(make_list)
    if (num >= 0 and num < 5):
        fn = services[num] + "_predictions"
    else:
        fn = "all_predictions"
    if (_api == 0):
        fn += "_api.csv"
    else:
        fn += "_ping.csv"
    df.to_csv(fn, index = False)
    return(mae)

def make_model(num):
    services = ["www.amazon.com", "www.walmart.com", "www.youtube.com", "www.yelp.com", "cs.stanford.edu"]

    header = "./api"
    files = os.listdir(header)

    header = "./ping"
    ping_files = os.listdir(header)

    header = ["Service", "IP", "API call", "Date", "Time", "Name lookup", "Connect time", "App Connect time", "Pretransfer", "Redirect", "Start Transfer", "TotalTime"]

    ping_header = ["Service", "IP", "Date", "Time", "List of Ping Times", "AvgPing"]

    all_api = []
    all_ping = []

    if (num >= 0 and num < 5): #index zero to four of services list
        print("Creating model for " + services[num] + ".\n\n")
        files = [x for x in files if services[num] in x]
        ping_files = [x for x in ping_files if services[num] in x]

    else:
        print("Creating model across all services.")

    for file in files:
        filename = "./api/" + file
        with open(filename, newline='') as f:
            reader = csv.reader(f)
            data = list(reader)
        for sublist in data:
            sublist[0] = services.index(sublist[0])
        all_api += data


    for file in ping_files:
        filename = "./ping/" + file
        with open(filename, newline='') as f:
            reader = csv.reader(f)
            data2 = list(reader)

        for sublist in data2:
            sublist[0] = services.index(sublist[0])
        all_ping += data2

    df = pd.DataFrame(all_api, columns = header)
    df["Date Time"] = pd.to_datetime(df["Date"] + ' ' + df["Time"])
    #df["Hour"] = df["Date Time"].dt.hour
    df["Hour"] = df["Time"].apply(toTime)
    #df1 = df[["Service", "Hour", "TotalTime"]]
    df["TotalTime"] = pd.to_numeric(df["TotalTime"], errors = 'coerce')

    ping_df = pd.DataFrame(all_ping, columns = ping_header)
    ping_df["Date Time"] = pd.to_datetime(ping_df["Date"] + ' ' + ping_df["Time"])
    #ping_df["Hour"] = ping_df["Date Time"].dt.hour
    ping_df["Hour"] = ping_df["Time"].apply(toTime)
    ping_df["AvgPing"] = pd.to_numeric(ping_df["AvgPing"], errors = 'coerce')
    #ping_df1 = ping_df[["Service", "Hour", "AvgPing"]]

    api_y = df.TotalTime
    if (num >= 0 and num < 5):
        api_features = ['Hour']
    else:
        api_features = ["Service", "Hour"]
    api_X = df[api_features]

    ping_y = ping_df.AvgPing
    ping_features = ["Service", "Hour"]
    ping_X = ping_df[ping_features]

    apitrain_X, apival_X, apitrain_y, apival_y = train_test_split(api_X, api_y, random_state = 0)

    pingtrain_X, pingval_X, pingtrain_y, pingval_y = train_test_split(ping_X, ping_y, random_state = 0)


    for max_leaf_nodes in [5, 10, 25, 50, 500, 5000]:
        api_mae = get_mae(max_leaf_nodes, apitrain_X, apival_X, apitrain_y, apival_y, num, 0)
        print("Max leaf nodes: %d \t\t API Mean Absolute Error: %f" %(max_leaf_nodes, api_mae))

    for max_leaf_nodes in [5, 10, 25, 50, 500, 5000]:
        ping_mae = get_mae(max_leaf_nodes, pingtrain_X, pingval_X, pingtrain_y, pingval_y, num, 1)
        print("Max leaf nodes: %d \t\t Ping Mean Absolute Error: %f" %(max_leaf_nodes, ping_mae))


for i in range(6):
    make_model(i)




# api_model = DecisionTreeRegressor(random_state = 1)
# api_model.fit(apitrain_X, apitrain_y)
# api_predictions = api_model.predict(apival_X)
# print(mean_absolute_error(apival_y, api_predictions))
#
# ping_model = DecisionTreeRegressor(random_state = 1)
# ping_model.fit(pingtrain_X, pingtrain_y)
# ping_predictions = ping_model.predict(pingval_X)
# print(mean_absolute_error(pingval_y, ping_predictions))
