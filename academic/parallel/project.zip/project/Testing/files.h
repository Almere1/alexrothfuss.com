#ifndef FILES_H_
#define FILES_H_

#include<pthread.h>

int fed_main();

int main_parallel(int t);

#endif /* FILES_H_ */
