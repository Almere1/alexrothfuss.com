//Alex Rothfuss - akrothfuss

#include <stdio.h>
#include "shell.h"
#include "library.h"

uint32_t fetch()
{
	NEXT_STATE.PC = CURRENT_STATE.PC + 4;
	return mem_read_32(CURRENT_STATE.PC);
}

operator decode(uint32_t instruction)
{
	if(instruction == 0xd4400000) return HLT;
	uint32_t inst = instruction >> 21;
	switch(inst){
//arithmatic operators
		case 0x458: return ADD;
		case 0x558: return ADDS;
		case 0x658: return SUB;
		case 0x758: return SUBS;
		case 0x4d8: return MUL;
		case 0x6b0: return BR;
//logical operators
		case 0x450: return AND;
		case 0x550: return ORR;
		case 0x650: return EOR;
		case 0x750: return ANDS;
//Store-Load
		case 0x7c0: return STUR;
		case 0x5c0: return STUR;
		case 0x7c2: return LDUR;
		case 0x5c2: return LDUR;
		case 0x3c0: return STURH;
		case 0x3c2: return LDURH;
		case 0x1c0: return STURB;
		case 0x1c2: return LDURB;
//Logical shifts
		case 0x69a: return LSR;
		case 0x69b: return LSL;
	}

	inst = inst >> 1;
	switch(inst){
//immediate arithmatic operators
		case 0x244: return ADDI;
		case 0x2c4: return ADDIS;
		case 0x344: return SUBI;
		case 0x3c4: return SUBIS;
	}
	
	inst = inst >> 1;
	if(inst == 0x1a5) return MOVZ;
	
	inst = inst >> 1;
	switch(inst){
		case 0xb4: return CBZ;
		case 0xb5: return CBNZ;
		case 0x54: return Bcond;
	}

	inst = inst >> 2;
	if(inst == 0x5) return B;
	else return 50;
}

void arithmatic(uint32_t instruction, _Bool sflag, _Bool add, _Bool imm){
	int64_t first = CURRENT_STATE.REGS[((0x000003e0 & instruction) >> 5)];
	int64_t secon;
	if(!imm) secon = CURRENT_STATE.REGS[((0x001f0000 & instruction) >> 16)];
	else secon = ((0x003ffc00 & instruction) >> 10);
	int32_t desti = (0x0000001f & instruction);
	int64_t res;
	
	if(add) res = first+secon;
	else res = first-secon;
	
	if(sflag){
		NEXT_STATE.FLAG_N = (res <  0);
		NEXT_STATE.FLAG_Z = (res == 0);
	}
	
	NEXT_STATE.REGS[desti] = res;
}

void multiply(uint32_t instruction){
	int64_t first = CURRENT_STATE.REGS[((0x000003e0 & instruction) >> 5)];
	int64_t secon = CURRENT_STATE.REGS[((0x001f0000 & instruction) >> 16)];
	int32_t desti = (0x0000001f & instruction);
	int64_t res;
	
	res = first*secon;
	
	NEXT_STATE.REGS[desti] = res;
}

void cb(uint32_t instruction, _Bool zero){
	int target = CURRENT_STATE.REGS[(0x0000001f & instruction)];
	int32_t branch = ((0x00ffffe0 & instruction) >> 5);
	if(zero && (!target)) NEXT_STATE.PC = CURRENT_STATE.PC + (0xffffffffffe00000 * ((branch & 0x00040000) == 0x00040000)) + (branch << 2);
	else if(!zero && (target)) NEXT_STATE.PC = CURRENT_STATE.PC + (0xffffffffffe00000 * ((branch & 0x00040000) == 0x00040000)) + (branch << 2);
}

void logic(uint32_t instruction, _Bool and, _Bool sFlagOr){
	int64_t first = CURRENT_STATE.REGS[((0x000003e0 & instruction) >> 5)];
	int64_t secon = CURRENT_STATE.REGS[((0x001f0000 & instruction) >> 16)];
	int32_t desti = (0x0000001f & instruction);
	int64_t res;
	
	if(and) res = first & secon;
	else if(sFlagOr) res = first | secon;
	else res = first ^ secon;
	
	if(and && sFlagOr){
		NEXT_STATE.FLAG_N = (res <  0);
		NEXT_STATE.FLAG_Z = (res == 0);
	}
	
	
	NEXT_STATE.REGS[desti] = res;
}

void load(uint32_t instruction, short length, _Bool load){
	int addition = (0x001ff000 & instruction) >> 12;
	int64_t first = CURRENT_STATE.REGS[((0x000003e0 & instruction) >> 5)];
	int32_t desti = (0x0000001f & instruction);
	
	int64_t ret = 0;
	if(load){
		ret += mem_read_32(first+addition); //check if need to do more if adds to value not divisable by 4	
		ret+=((uint64_t)(mem_read_32(first+addition+4)) << 32);
	} else ret = CURRENT_STATE.REGS[desti];
	
			
	if(length == 1)      ret = ret & 0x00000000000000ff;
	else if(length == 2) ret = ret & 0x000000000000ffff;
	else if(length == 3) ret = ret & 0x00000000ffffffff;
	
	if(load) NEXT_STATE.REGS[desti] = ret;
	else{
		int32_t returnval = mem_read_32(first+addition); //check if need to do more if adds to value not divisable by 4	
		if(ret == 1) returnval = (returnval & 0xffffff00) + ret;
		else if(ret == 2) returnval = (returnval & 0xffff0000) + ret;
		else returnval = ret & 0xffffffff;
		mem_write_32(first+addition, returnval);
		if(ret == 4) mem_write_32(first+addition+4, (ret >> 32));
	}
}

void move(uint32_t instruction){
	uint64_t ret = (0x001fffe0 & instruction) >> 5;
	int desti = (0x0000001f & instruction);
	
	NEXT_STATE.REGS[desti] = ret;
}

void shift(uint32_t instruction, _Bool right){
	int shift = ((instruction >> 10) & 0x000003ff);
	int64_t first = CURRENT_STATE.REGS[((0x000003e0 & instruction) >> 5)];
	short desti = (0x0000001f & instruction);
	
	if(right) first = first >> ((instruction >> 16) & 0x3f);
	else first = first << (63-shift);
	
	NEXT_STATE.REGS[desti] = first;
}

void br(uint32_t instruction){
	NEXT_STATE.PC = CURRENT_STATE.REGS[(instruction & 0x000003e0)>>5];
}

void b(uint32_t instruction){
	uint64_t total = instruction & 0x03ffffff;
	if(total & (0x02000000)) total += 0xfffffffffc000000;
	total = total << 2;
	NEXT_STATE.PC = (CURRENT_STATE.PC + total);
}

void bcomp(uint32_t instruction){
	_Bool equal = CURRENT_STATE.FLAG_Z;
	_Bool less = CURRENT_STATE.FLAG_N;
	_Bool pass = 1;
	short flags = (0xf & instruction);
	switch(flags){
		case 0x0: 	pass = equal;
				break;
		case 0x1:	pass = !(equal);
				break;
		case 0xc:	pass = !(equal) && !(less);
				break;
		case 0xb:	pass = !(equal) && less;
				break;
		case 0xd:	pass = (equal || less);
				break;
		case 0xa:	pass = !(less);
				break;
	}
	
	if(pass){
		uint64_t total = instruction & 0x00ffffe0;
		total = total >> 3;
		if(total & (0x00100000)) total += 0xffffffffffe00000;
		NEXT_STATE.PC = (CURRENT_STATE.PC + total);
	}
}

void process_instruction()
{
    /* execute one instruction here. You should use CURRENT_STATE and modify
     * values in NEXT_STATE. You can call mem_read_32() and mem_write_32() to
     * access memory. */
	NEXT_STATE.PC = CURRENT_STATE.PC + 4;
	uint32_t opcode = fetch();
	int opval = decode(opcode);
	
	if(opval<8){
		_Bool sflag, add, imm;
		imm = opval<4 ? 0 : 1;
		sflag = (opval%2 == 0) ? 0 : 1;
		add = (2 & opval) ? 0 : 1;
		arithmatic(opcode, sflag, add, imm);
	}
	else if(opval == 8) multiply(opcode);
	else if(opval < 11) cb(opcode, (opval == 10));
	else if(opval < 15){
		_Bool and, sFlag;
		and = (opval<13) ? 1 : 0;
		sFlag = (opval%2) ? 0 : 1;
		logic(opcode, and, sFlag);
	}
	else if(opval < 21){
		_Bool loa = (opval < 18);
		short length;
		uint32_t temp = (0xe0000000 & opcode);
		if(temp == 0xe0000000) length = 4;
		else if(temp == 0xa0000000) length = 3;
		else if(temp == 0x60000000) length = 2;
		else length = 1;
		load(opcode, length, loa);	
	}
	else if(opval == 21) move(opcode);
	else if(opval < 24){
		_Bool right = (opval == 23) ? 1 : 0;
		shift(opcode, right);
	}
	else if(opval == 24) br(opcode);
	else if(opval == 25) b(opcode);
	else if(opval == 26) bcomp(opcode);
	else if(opval == 27) RUN_BIT = 0;
	else if(opval == 50) NEXT_STATE.PC = CURRENT_STATE.PC + 4;
	
}
